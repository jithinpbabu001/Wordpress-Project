<?php 
require('mysqli_connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
            
            
            $firstname= $_POST['first_name'];
			$lastname = $_POST['last_name'];
            $product_id= $_GET['id'];
            $qua= $_GET['qua'];
            
    
               
            
            $quantity_new=$qua-1;
            
                $q="INSERT INTO users(first_name, last_name, product_id) values ('$firstname', '$lastname', '$product_id')";
                $r = @mysqli_query($dbc,$q);
                $s="UPDATE products SET quantity = $quantity_new WHERE p_id = $product_id";
                $t = @mysqli_query($dbc, $s);
                
                
                
                
                
            echo 'Confirm order on the below address<br>';
            echo 'First name : ' .$firstname. '<br>';
            echo 'Last name : ' .$lastname;
            
            
            
			
		}
?>
<html>
    <a href="store.php">Confirm Order</a>
</html>