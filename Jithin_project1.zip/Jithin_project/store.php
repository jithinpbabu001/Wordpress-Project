<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
   
   

ul.topnav li {float: left;}

ul.topnav li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

ul.topnav li a:hover:not(.active) {background-color: #111;}

ul.topnav li a.active {background-color: #4CAF50;}

ul.topnav li.right {float: right;}

@media screen and (max-width: 600px) {
  ul.topnav li.right, 
  ul.topnav li {float: none;}
}
     .grid{
        width:320px;
        height: 320px;
         padding-left:10%;
         padding-right:auto;
         float:left;
    }
    
     
    .foot{
   
        background-color: #263238;
        color: aliceblue;
        height: 50px;
        margin-bottom:1080px;
        text-align: center;
        vertical-align: middle;
        
    }
ul.topnav {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}
</style>
    </head>
    <body>

<ul class="topnav">
  <li><a  href="index.html">Home</a></li>
  <li><a class="active">Products</a></li>
</ul>

<div style="padding-top:50px; padding-bottom:50px">
    
    
<?php
require('mysqli_connect.php');

$q = "SELECT * FROM product";
$r = @mysqli_query($dbc,$q);

echo '<table width="60%">
<thead>
<tr>
<th align="left">Name</th>
<th align="left">Quantity</th>
 </tr>
</thead>
<tbody>';

while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
echo '<div class="grid"><a href="cart.php?id=' . $row['prod_id'] .  '"><br>' . $row['prod_name'] . '<br>Quantity:' . $row['prod_quantity'].'<br><img height="240px" width="240px "src="/jithin_project/upload/'.$row['prod_image'].'"></a></div>';
 }

echo'<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>'

?>
    
    
     </div>
    
    </body>
    <footer><div class="foot">© 2018 Copyright: ecommerse</div></footer>
</html>
