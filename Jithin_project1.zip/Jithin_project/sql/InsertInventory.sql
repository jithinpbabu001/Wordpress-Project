INSERT INTO `product` (`prod_id`, `prod_name`, `prod_quantity`, `prod_image`, `price`) VALUES
(1, 'shirt', '9', 'abc.jpg', 10),
(2, 't-shirt', '19', 'bcd.jpg', 14),
(3, 'jacket', '15', 'cde.jpg', 17),
(4, 'shoe', '10', 'def.jpg', 19),
(5, 'sportwear', '13', 'efg.jpg', 11),
(6, 'cap', '10', 'ghi.jpg', 10);