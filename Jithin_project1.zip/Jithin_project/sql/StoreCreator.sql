CREATE TABLE IF NOT EXISTS `product` (
  `prod_id` int(10) NOT NULL,
  `prod_name` varchar(20) NOT NULL,
  `prod_quantity` varchar(20) NOT NULL,
  `prod_image` varchar(20) NOT NULL,
  `price` int(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `users` (
  `u_id` int(10) NOT NULL,
  `f_name` varchar(20) NOT NULL,
  `l_name` varchar(20) NOT NULL,
  `prod_id` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
ALTER TABLE `product`
  ADD PRIMARY KEY (`prod_id`);
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);
ALTER TABLE `product`
  MODIFY `prod_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
ALTER TABLE `users`
  MODIFY `u_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;